#!/data/data/com.termux/files/usr/bin/bash
# Termux NATIVO: non tocca Ubuntu, progetti o sessioni esistenti.
set -euo pipefail
pkg install -y openssh tmux
printf '\nUTENTE TERMUX: '; whoami
printf '\nIMPRONTA DEL SERVER SSH (da incollare nelle impostazioni Workspace):\n'
ssh-keygen -lf "$PREFIX/etc/ssh/ssh_host_ed25519_key.pub" -E sha256
printf '\nSessioni esistenti:\n'
tmux list-sessions 2>/dev/null || true
printf '\nAvvio SSH solo su localhost:8022...\n'
if ! (echo >/dev/tcp/127.0.0.1/8022) >/dev/null 2>&1; then
    sshd -p 8022 -o ListenAddress=127.0.0.1
else
    echo 'SSH gia attivo sulla porta 8022.'
fi
printf '\nSe non hai ancora impostato una password per Termux, esegui: passwd\n'
printf 'Per evitare sospensioni in sessioni lunghe: termux-wake-lock e batteria Senza restrizioni per Termux.\n'
