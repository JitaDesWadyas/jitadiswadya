#!/data/data/com.termux/files/usr/bin/bash
# Best effort build for ARM64 devices. Requires Android SDK 35, Gradle 8.9, JDK 17+.
set -euo pipefail
cd "$(dirname "$0")/.."
: "${ANDROID_HOME:=$HOME/android-sdk}"
export ANDROID_HOME
export JAVA_HOME="${JAVA_HOME:-$PREFIX/lib/jvm/java-17-openjdk}"
export PATH="$JAVA_HOME/bin:$PATH"

AAPT2="$(command -v aapt2 || true)"
if [ -z "$AAPT2" ]; then
  echo 'Installa aapt2 ARM64: pkg install aapt2'
  exit 1
fi
if ! command -v gradle >/dev/null; then
  echo 'Gradle non trovato. Installa Gradle 8.9 o usa Android Studio su PC.'
  echo 'Il pacchetto non include una distribuzione Gradle.'
  exit 1
fi
printf 'sdk.dir=%s\n' "$ANDROID_HOME" > local.properties
# AGP otherwise downloads an x86_64 AAPT2 binary, which cannot run on the phone.
gradle assembleDebug --no-daemon -Pandroid.aapt2FromMavenOverride="$AAPT2"
printf '\nAPK: %s\n' "$PWD/app/build/outputs/apk/debug/app-debug.apk"
