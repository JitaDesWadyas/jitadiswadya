# Termux Workspace · FEIM Edition v0.2

Aggiornamento della stessa app Android (stesso `applicationId`): non cancella le impostazioni salvate se si installa una nuova build firmata con la stessa chiave. Le build debug GitHub su runner effimeri possono avere firme diverse: in quel caso Android richiede la disinstallazione della versione precedente, perdendo le impostazioni dell'app ma **non** i dati di Termux.

## Novità

- Corretto `SSH locale: no such algorithm: X25519 for provider BC` con provider Bouncy Castle moderno, verificato prima della connessione.
- Interfaccia FEIM-OTT: ink/ivory/brass, pannelli tattili e griglia tattica leggera.
- Tema coerente fra dashboard, connessione, progetti, terminale xterm.
- Impronta SSH del server sempre obbligatoria, solo `127.0.0.1`.

## Verifica su dispositivo

1. In Termux nativo: `sshd`, quindi `whoami` e `ssh-keygen -lf "$PREFIX/etc/ssh/ssh_host_ed25519_key.pub" -E sha256`.
2. Nell'app configura username, password, porta `8022` e fingerprint `SHA256:...`.
3. Premi Verifica collegamento; se funziona entra in Codex, poi prova `tmux ls`.
4. Se la versione precedente è firmata con una chiave debug diversa, conserva una copia dei quattro dati di connessione prima di reinstallare.

# Termux Workspace — REDMAGIC

App Android **nativa** (Kotlin + Jetpack Compose) che usa **un unico Termux e un unico Ubuntu**, senza root, senza X11, senza duplicare progetti. È un progetto sorgente pronto da aprire in Android Studio; non è un APK già compilato.

## Cosa c'è in questa prima versione

- Dashboard Android dark/touch, 5 card: Codex, Claude, MNF, FEIM, Ubuntu.
- **Sei icone nel launcher**: la dashboard e 5 terminali, tutti nello stesso pacchetto APK.
- **Cinque task Android distinti** grazie alle diverse `taskAffinity`, con ingresso diretto dalle icone e dalle app recenti.
- Terminale ANSI con xterm.js **integrato offline** in una WebView interna; barra Ctrl/Esc/Tab/frecce e tastiera Android.
- Ogni icona si collega a **una sessione `tmux` con nome diverso** (`w_codex`, `w_claude`, `w_mnf`, `w_feim`, `w_ubuntu`) nello stesso Termux; le sessioni restano attive se chiudi la finestra, purché Android non termini Termux.
- Pulsante Play: esegue il comando originale modificabile (Codex `codex-work`, Claude `claude`, MNF `mnf-work`, FEIM `feim`, Ubuntu `ubuntu-go`). Non lo invia automaticamente, perché alcuni tuoi launcher potrebbero già gestire `tmux`.
- Scheda File tramite SFTP locale (navigazione e **anteprima di testo fino a 64 KiB**). Per editare/spostare file complessi, continua a usare Material Files.
- Scheda Processi per vedere sessioni `tmux` e processi Termux.
- Login SSH con password **cifrata tramite Android Keystore AES-256-GCM**, host fisso a `127.0.0.1` e **impronta SSH obbligatoria**. Nessun server esterno.

## Installazione: parte Termux

Apri **Termux nativo**, non Ubuntu. Non cancellare o reinstallare niente.

```bash
pkg install openssh tmux
whoami
passwd    # imposta una password se non ne hai già una
ssh-keygen -lf "$PREFIX/etc/ssh/ssh_host_ed25519_key.pub" -E sha256
sshd -p 8022 -o ListenAddress=127.0.0.1
```

`sshd` può essere già in esecuzione sulla porta 8022: se lo è, non avviare un secondo demone. Accertati che ascolti solo su loopback (per esempio `ss -ltn | grep 8022`). In alternativa esegui `scripts/termux-bootstrap.sh` in Termux nativo.

Apri l'app, entra in **Config**, inserisci l'utente ottenuto con `whoami`, la password, la porta 8022 e la stringa `SHA256:...` emessa da `ssh-keygen -lf`. Salva e scegli **Verifica collegamento**. Se la chiave SSH dell'host cambia, correggi l'impronta soltanto dopo averla verificata direttamente in Termux.

Per aumentare la persistenza in background: imposta Termux su **Batteria → Senza restrizioni** sul REDMAGIC e, quando opportuno, `termux-wake-lock`. Il sistema operativo mantiene comunque il diritto di terminare i processi sotto pressione di memoria o per politiche energetiche. Non promettiamo 100 ore di uptime garantito.

## Compilazione dell'APK

### Consigliata: Android Studio su un PC

1. Apri la cartella `TermuxWorkspace` come progetto Gradle.
2. Usa JDK 17 o successivo e Android SDK API 35.
3. Sincronizza Gradle e fai `Build → Build APK(s)`.
4. L'APK debug si troverà in `app/build/outputs/apk/debug/app-debug.apk`.
5. Copialo sul REDMAGIC e installalo.

Serve Internet al **primo build** per recuperare il Gradle Plugin, Compose e SSHJ da Google Maven/Maven Central. Non è necessario durante l'uso dell'app.

### Alternativa: GitHub Actions

Nel progetto è incluso `.github/workflows/android-debug-apk.yml`. Se carichi i file in un repository GitHub, Actions può compilare un APK `debug` su un runner Linux con SDK ufficiale. Nella sezione **Actions** trovi l'artifact `termux-workspace-debug-apk` da scaricare. Non inserire in repository alcuna password, chiave SSH privata o dati migrati: in questo progetto **non ce ne sono**.

### Sul REDMAGIC stesso (sperimentale)

Il tuo telefono ha JDK e Android SDK ripristinati. Il problema è che Android Gradle Plugin include un `aapt2` per PC: il build script punta al binario ARM64 di Termux.

```bash
pkg install aapt2
# Scarica/installa Gradle 8.9 compatibile, se manca.
export ANDROID_HOME="$HOME/android-sdk"
./scripts/build-on-termux.sh
```

Se Gradle o il toolchain Android non sono disponibili, usa Android Studio o una CI. Il build sul telefono non è stato verificato in questa sessione.

## Note tecniche

- Non viene creato un secondo server SSH: la UI si collega a quello esistente via `127.0.0.1:8022`.
- Non vengono copiati Termux, Ubuntu, il database MNF o i sorgenti FEIM.
- **Termux resta il vero motore di background**, mentre ogni task Android fornisce una nuova vista SSH. I nomi delle sessioni sono volutamente nuovi, per non alterare le tue vecchie sessioni.
- Le sessioni nuove si aprono con una shell; il pulsante Play esegue il comando del progetto. È così possibile prima controllare che il comando personalizzato sia ancora quello giusto.
- Questa versione non aggiunge un editor completo o un pannello desktop Linux: contiene un file browser e terminali touch, senza Termux:X11.
- La persistenza dell'output dentro una sessione tmux **non è infinita**: riaprendo una finestra avrai il buffer disponibile di tmux, non necessariamente l'intera cronologia dal giorno prima.

## Requisiti/versioni

- Kotlin 2.1.10, Android Gradle Plugin 8.7.3, Compose BOM 2025.02.00.
- SSHJ 0.41.2 da Maven Central.
- xterm.js 3.x (bundle browser), risorse statiche nel progetto sotto `app/src/main/assets/terminal`.
- minSdk 26 / targetSdk 35. REDMAGIC Android 17 compatibile a livello di API, **ma il funzionamento sul dispositivo non è ancora testato**.

## Limiti attuali

**Non ho potuto compilare e verificare l'APK qui**: nell'ambiente di creazione non sono installati Android SDK/Gradle e la rete verso i repository Maven non è disponibile. Il progetto è concreto e contiene la logica applicativa, ma il primo build può richiedere piccoli aggiustamenti di dipendenze o compatibilità SSHJ/Android. Questo non è un rilascio collaudato.
