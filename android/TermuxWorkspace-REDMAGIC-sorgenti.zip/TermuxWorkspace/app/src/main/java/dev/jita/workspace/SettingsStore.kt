package dev.jita.workspace

import android.content.Context
import android.os.Build
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** Keystore-bound encryption: no credentials in the APK, shell history or plain preferences. */
class SettingsStore(context: Context) {
    private val prefs = context.getSharedPreferences("workbench_settings", Context.MODE_PRIVATE)
    private val alias = "workbench-ssh-secret-v1"

    private fun key(): SecretKey {
        val store = KeyStore.getInstance("AndroidKeyStore")
        store.load(null)
        (store.getKey(alias, null) as? SecretKey)?.let { return it }
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        gen.init(
            KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return gen.generateKey()
    }

    private fun encrypt(value: String): String {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key())
        val joined = cipher.iv + cipher.doFinal(value.toByteArray(Charsets.UTF_8))
        return Base64.encodeToString(joined, Base64.NO_WRAP)
    }

    private fun decrypt(value: String): String = try {
        val data = Base64.decode(value, Base64.NO_WRAP)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, data.copyOfRange(0, 12)))
        String(cipher.doFinal(data.copyOfRange(12, data.size)), Charsets.UTF_8)
    } catch (_: Exception) {
        "" // Device backup/restore must not silently re-use credentials whose key is absent.
    }

    fun load(): ConnectionSettings = ConnectionSettings(
        username = prefs.getString("user", "").orEmpty(),
        password = prefs.getString("secret", "")?.takeIf { it.isNotBlank() }?.let(::decrypt).orEmpty(),
        fingerprint = prefs.getString("host_fp", "").orEmpty(),
        port = prefs.getInt("port", 8022)
    )

    fun save(username: String, fingerprint: String, port: Int, newPassword: String) {
        prefs.edit().apply {
            putString("user", username.trim())
            putString("host_fp", fingerprint.trim())
            putInt("port", port)
            if (newPassword.isNotEmpty()) putString("secret", encrypt(newPassword))
        }.apply()
    }

    fun clearPassword() { prefs.edit().remove("secret").apply() }

    fun startupCommand(space: Workspace): String =
        prefs.getString("startup_${space.name}", space.quickCommand).orEmpty()

    fun setStartupCommand(space: Workspace, command: String) =
        prefs.edit().putString("startup_${space.name}", command).apply()
}
