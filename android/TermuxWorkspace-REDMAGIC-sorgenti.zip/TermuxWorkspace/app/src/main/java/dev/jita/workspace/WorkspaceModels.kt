package dev.jita.workspace

import androidx.compose.ui.graphics.Color

enum class Workspace(
    val title: String,
    val subtitle: String,
    val sessionName: String,
    val quickCommand: String,
    val accent: Color,
    val tag: String
) {
    CODEX("Codex", "Agente di sviluppo", "w_codex", "codex-work", Color(0xFF69AAFA), "CX"),
    CLAUDE("Claude", "Agente e automazioni", "w_claude", "claude", Color(0xFFF4AC80), "CL"),
    MNF("MNF", "MoneyFarm & Taylor", "w_mnf", "mnf-work", Color(0xFF5FDEBD), "MF"),
    FEIM("FEIM", "Sviluppo del gioco", "w_feim", "feim", Color(0xFFC0A7FF), "FM"),
    UBUNTU("Ubuntu", "Linux e toolchain", "w_ubuntu", "ubuntu-go", Color(0xFFFFCC80), "UB");
}

data class ConnectionSettings(
    val username: String = "",
    val password: String = "",
    val fingerprint: String = "",
    val port: Int = 8022
) {
    val configured get() = username.isNotBlank() && password.isNotBlank() && fingerprint.isNotBlank()
}

data class FileEntry(val name: String, val directory: Boolean, val size: Long = 0L)

fun shQuote(v: String): String = "'" + v.replace("'", "'\\''") + "'"
