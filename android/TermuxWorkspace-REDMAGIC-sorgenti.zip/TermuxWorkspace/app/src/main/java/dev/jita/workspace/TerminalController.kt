package dev.jita.workspace

import android.annotation.SuppressLint
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import net.schmizz.sshj.SSHClient
import net.schmizz.sshj.connection.channel.direct.Session
import java.util.concurrent.atomic.AtomicBoolean

/** One SSH terminal per Android task; tmux lives in the SINGLE original Termux install. */
class TerminalController(
    private val context: Context,
    private val workspace: Workspace,
    private val store: SettingsStore
) {
    var status by mutableStateOf("Pronto")
        private set
    var ctrlArmed by mutableStateOf(false)
        private set
    private val main = Handler(Looper.getMainLooper())
    private val started = AtomicBoolean(false)
    private val active = AtomicBoolean(true)
    private val sendLock = Any()
    @Volatile private var ssh: SSHClient? = null
    @Volatile private var session: Session? = null
    @Volatile private var shell: Session.Shell? = null
    @Volatile private var web: WebView? = null
    private var lastColumns = 80
    private var lastRows = 28

    private fun setStatus(value: String) = main.post { if (active.get()) status = value }

    @SuppressLint("SetJavaScriptEnabled", "JavascriptInterface")
    fun makeWebView(context: Context): WebView = WebView(context).apply {
        setBackgroundColor(android.graphics.Color.rgb(10, 16, 24))
        settings.javaScriptEnabled = true
        settings.allowFileAccess = true
        settings.allowContentAccess = false
        settings.domStorageEnabled = false
        settings.setSupportZoom(false)
        settings.allowFileAccessFromFileURLs = false
        settings.allowUniversalAccessFromFileURLs = false
        addJavascriptInterface(TerminalJsBridge(), "Native")
        webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean = true
            override fun onPageFinished(view: WebView, url: String?) {
                if (!active.get()) return
                web = view
                start()
            }
        }
        loadUrl("file:///android_asset/terminal/index.html")
    }

    inner class TerminalJsBridge {
        @JavascriptInterface fun input(value: String) { sendInput(value) }
        @JavascriptInterface fun resized(columns: Int, rows: Int) {
            lastColumns = columns.coerceIn(20, 300)
            lastRows = rows.coerceIn(8, 150)
            Thread { runCatching { shell?.changeWindowDimensions(lastColumns, lastRows, 0, 0) } }.start()
        }
    }

    private fun start() {
        if (!started.compareAndSet(false, true)) return
        if (!store.load().configured) {
            setStatus("Configura SSH dalla home → Impostazioni")
            write("\r\n  Configurazione SSH mancante.\r\n  Torna alla dashboard e apri Impostazioni.\r\n")
            return
        }
        Thread({
            try {
                setStatus("Connessione…")
                val client = SshGateway(store.load())
                client.withClient { remote ->
                    ssh = remote
                    val newSession = remote.startSession()
                    session = newSession
                    // Fallback to an interactive login shell with a proper pseudoterminal.
                    newSession.allocateDefaultPTY()
                    val newShell = newSession.startShell()
                    shell = newShell
                    runCatching { newShell.changeWindowDimensions(lastColumns, lastRows, 0, 0) }
                    setStatus("Connesso · ${workspace.sessionName}")
                    val launch = "tmux new-session -A -s ${workspace.sessionName}\n"
                    newShell.outputStream.write(launch.toByteArray(Charsets.UTF_8))
                    newShell.outputStream.flush()
                    val buffer = ByteArray(4096)
                    while (active.get()) {
                        val count = newShell.inputStream.read(buffer)
                        if (count < 0) break
                        if (count > 0) writeRaw(buffer.copyOf(count))
                    }
                }
                if (active.get()) setStatus("Disconnesso · riapri la finestra")
            } catch (e: Exception) {
                if (active.get()) {
                    setStatus("Errore SSH: ${e.message?.take(100) ?: "sconosciuto"}")
                    write("\r\n\u001b[31mConnessione fallita\u001b[0m\r\n${e.message.orEmpty()}\r\n")
                }
            } finally {
                ssh = null
                session = null
                shell = null
            }
        }, "termux-${workspace.name.lowercase()}").start()
    }

    private fun write(value: String) = writeRaw(value.toByteArray(Charsets.UTF_8))

    private fun writeRaw(data: ByteArray) {
        val encoded = Base64.encodeToString(data, Base64.NO_WRAP)
        main.post {
            if (active.get()) web?.evaluateJavascript("window.termWriteB64('$encoded');", null)
        }
    }

    fun sendInput(value: String) {
        if (!active.get()) return
        val text = if (ctrlArmed && value.length == 1 && value[0].isLetter()) {
            main.post { ctrlArmed = false }
            ((value.uppercase()[0].code and 31).toChar()).toString()
        } else {
            if (ctrlArmed) main.post { ctrlArmed = false }
            value
        }
        synchronized(sendLock) {
            runCatching {
                shell?.outputStream?.let { stream ->
                    stream.write(text.toByteArray(Charsets.UTF_8))
                    stream.flush()
                }
            }.onFailure { setStatus("Invio fallito: ${it.message}") }
        }
    }

    fun reconnect() {
        if (shell != null) return
        started.set(false)
        start()
    }

    fun toggleCtrl() { ctrlArmed = !ctrlArmed }
    fun runCommand(command: String) {
        if (command.isBlank()) return
        sendInput("$command\n")
    }

    fun focusKeyboard() {
        main.post {
            web?.let { view ->
                view.requestFocus()
                view.evaluateJavascript("window.termFocus && window.termFocus();", null)
                val ime = context.getSystemService(Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
                ime.showSoftInput(view, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT)
            }
        }
    }

    fun close() {
        active.set(false)
        val oldSession = session
        val oldSsh = ssh
        Thread {
            runCatching { oldSession?.close() }
            runCatching { oldSsh?.disconnect() }
        }.start()
        web?.let { view ->
            main.post {
                view.removeJavascriptInterface("Native")
                view.stopLoading()
                view.destroy()
            }
        }
        web = null
    }
}
