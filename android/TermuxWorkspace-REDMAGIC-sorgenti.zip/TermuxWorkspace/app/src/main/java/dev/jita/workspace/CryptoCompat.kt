package dev.jita.workspace

import org.bouncycastle.jce.provider.BouncyCastleProvider
import java.security.Security
import javax.crypto.KeyAgreement

/**
 * Android ships a stripped provider called BC which lacks X25519 on some releases.
 * SSHJ explicitly asks for provider BC, so the platform's BC must be replaced
 * with the modern bundled provider in this app process, before opening SSH.
 */
internal object CryptoCompat {
    @Synchronized
    fun ensureX25519() {
        val existing = Security.getProvider("BC")
        val usable = runCatching { KeyAgreement.getInstance("X25519", "BC") }.isSuccess
        if (usable) return
        if (existing != null) Security.removeProvider("BC")
        val inserted = Security.insertProviderAt(BouncyCastleProvider(), 1)
        check(inserted > 0) { "Provider crittografico BC non registrato" }
        try {
            KeyAgreement.getInstance("X25519", "BC")
        } catch (e: Exception) {
            throw IllegalStateException("Il provider BC aggiornato non supporta X25519", e)
        }
    }
}
