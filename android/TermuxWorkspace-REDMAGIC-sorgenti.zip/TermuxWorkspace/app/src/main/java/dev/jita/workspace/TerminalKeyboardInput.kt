package dev.jita.workspace

import android.content.Context
import android.graphics.Color
import android.text.InputType
import android.util.TypedValue
import android.view.KeyEvent
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.view.inputmethod.InputConnectionWrapper
import android.widget.EditText

/**
 * Android IME bridge for SSH: keys reach the remote PTY immediately, not a local command box.
 * Keeps the native Android keyboard usable even if the xterm WebView hidden textarea loses focus.
 */
class TerminalKeyboardInput(context: Context, private val emit: (String) -> Unit) : EditText(context) {
    init {
        inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD or
            InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        imeOptions = EditorInfo.IME_FLAG_NO_EXTRACT_UI or EditorInfo.IME_FLAG_NO_FULLSCREEN or
            EditorInfo.IME_ACTION_NONE
        setSingleLine(true)
        setTextColor(Color.TRANSPARENT)
        setBackgroundColor(Color.TRANSPARENT)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 1f)
        setPadding(0, 0, 0, 0)
        isFocusable = true
        isFocusableInTouchMode = true
    }

    override fun onCreateInputConnection(outAttrs: EditorInfo): InputConnection? {
        val original = super.onCreateInputConnection(outAttrs) ?: return null
        outAttrs.imeOptions = outAttrs.imeOptions or EditorInfo.IME_FLAG_NO_EXTRACT_UI or
            EditorInfo.IME_FLAG_NO_FULLSCREEN
        return object : InputConnectionWrapper(original, true) {
            override fun commitText(text: CharSequence?, newCursorPosition: Int): Boolean {
                val textToSend = text?.toString().orEmpty()
                val result = super.commitText(text, newCursorPosition)
                if (textToSend.isNotEmpty()) emit(textToSend)
                // This is a one-way PTY input bridge. Never accumulate text locally.
                post { setText("") }
                return result
            }

            override fun deleteSurroundingText(beforeLength: Int, afterLength: Int): Boolean {
                if (beforeLength > 0) emit("\u007f".repeat(beforeLength.coerceAtMost(32)))
                if (afterLength > 0) emit("\u001b[3~".repeat(afterLength.coerceAtMost(32)))
                return super.deleteSurroundingText(beforeLength, afterLength)
            }

            override fun deleteSurroundingTextInCodePoints(beforeLength: Int, afterLength: Int): Boolean {
                if (beforeLength > 0) emit("\u007f".repeat(beforeLength.coerceAtMost(32)))
                if (afterLength > 0) emit("\u001b[3~".repeat(afterLength.coerceAtMost(32)))
                return super.deleteSurroundingTextInCodePoints(beforeLength, afterLength)
            }

            override fun sendKeyEvent(event: KeyEvent): Boolean {
                if (event.action == KeyEvent.ACTION_DOWN) {
                    when (event.keyCode) {
                        KeyEvent.KEYCODE_DEL -> { emit("\u007f"); return true }
                        KeyEvent.KEYCODE_ENTER -> { emit("\r"); return true }
                        KeyEvent.KEYCODE_TAB -> { emit("\t"); return true }
                        KeyEvent.KEYCODE_DPAD_UP -> { emit("\u001b[A"); return true }
                        KeyEvent.KEYCODE_DPAD_DOWN -> { emit("\u001b[B"); return true }
                        KeyEvent.KEYCODE_DPAD_LEFT -> { emit("\u001b[D"); return true }
                        KeyEvent.KEYCODE_DPAD_RIGHT -> { emit("\u001b[C"); return true }
                    }
                }
                return super.sendKeyEvent(event)
            }

            override fun performEditorAction(actionCode: Int): Boolean {
                emit("\r")
                return true
            }
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        when (keyCode) {
            KeyEvent.KEYCODE_ENTER -> { emit("\r"); return true }
            KeyEvent.KEYCODE_DEL -> { emit("\u007f"); return true }
            KeyEvent.KEYCODE_TAB -> { emit("\t"); return true }
            KeyEvent.KEYCODE_DPAD_LEFT -> { emit("\u001b[D"); return true }
            KeyEvent.KEYCODE_DPAD_RIGHT -> { emit("\u001b[C"); return true }
            KeyEvent.KEYCODE_DPAD_UP -> { emit("\u001b[A"); return true }
            KeyEvent.KEYCODE_DPAD_DOWN -> { emit("\u001b[B"); return true }
        }
        val value = event.unicodeChar
        if (value != 0 && !event.isCtrlPressed && Character.isValidCodePoint(value)) {
            emit(String(Character.toChars(value)))
            return true
        }
        return super.onKeyDown(keyCode, event)
    }
}
