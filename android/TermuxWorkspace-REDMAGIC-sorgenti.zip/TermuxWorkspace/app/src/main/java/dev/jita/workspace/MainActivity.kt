package dev.jita.workspace

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val store = SettingsStore(applicationContext)
        setContent {
            WorkbenchTheme {
                var tab by rememberSaveable { mutableIntStateOf(if (intent?.getStringExtra("tab") == "settings") 3 else 0) }
                MainScreen(store, tab, { tab = it }) { space ->
                    val target = when (space) {
                        Workspace.CODEX -> CodexActivity::class.java
                        Workspace.CLAUDE -> ClaudeActivity::class.java
                        Workspace.MNF -> MnfActivity::class.java
                        Workspace.FEIM -> FeimActivity::class.java
                        Workspace.UBUNTU -> UbuntuActivity::class.java
                    }
                    startActivity(Intent(this, target).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
            }
        }
    }
}

abstract class TerminalActivity(private val workspace: Workspace) : ComponentActivity() {
    private lateinit var terminal: TerminalController

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        val store = SettingsStore(applicationContext)
        terminal = TerminalController(applicationContext, workspace, store)
        setContent {
            WorkbenchTheme {
                TerminalScreen(
                    workspace,
                    terminal,
                    store,
                    onDashboard = { startActivity(Intent(this, MainActivity::class.java)); finish() },
                    onSettings = {
                        startActivity(Intent(this, MainActivity::class.java).putExtra("tab", "settings"))
                    }
                )
            }
        }
    }

    override fun onDestroy() {
        terminal.close()
        super.onDestroy()
    }
}

class CodexActivity : TerminalActivity(Workspace.CODEX)
class ClaudeActivity : TerminalActivity(Workspace.CLAUDE)
class MnfActivity : TerminalActivity(Workspace.MNF)
class FeimActivity : TerminalActivity(Workspace.FEIM)
class UbuntuActivity : TerminalActivity(Workspace.UBUNTU)
