package dev.jita.workspace

import net.schmizz.sshj.SSHClient
import net.schmizz.sshj.connection.channel.direct.Session
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.util.concurrent.TimeUnit

/** SSH only to the local Termux daemon. Fingerprint is mandatory and verified. */
class SshGateway(private val config: ConnectionSettings) {
    private fun connection(): SSHClient {
        require(config.configured) { "Configura utente, password e impronta SSH in Impostazioni." }
        require(config.port in 1024..65535) { "Porta non valida" }
        require(config.fingerprint.startsWith("SHA256:") || config.fingerprint.startsWith("MD5:")) {
            "L'impronta deve iniziare con SHA256: o MD5:"
        }
        val ssh = SSHClient()
        try {
            ssh.addHostKeyVerifier(config.fingerprint.trim())
            ssh.connect("127.0.0.1", config.port)
            ssh.authPassword(config.username, config.password)
        } catch (error: Exception) {
            runCatching { ssh.disconnect() }
            throw IOException("SSH locale: ${error.message ?: error.javaClass.simpleName}", error)
        }
        return ssh
    }

    fun <T> withClient(action: (SSHClient) -> T): T {
        val ssh = connection()
        return try { action(ssh) } finally { runCatching { ssh.disconnect() } }
    }

    fun test(): String = withClient { ssh ->
        exec(ssh, "printf 'SSH OK\\n'; command -v tmux; echo \$HOME", 4096)
    }

    fun sessionsAndProcesses(): String = withClient { ssh ->
        exec(
            ssh,
            "printf '=== SESSIONI TMUX ===\\n'; tmux list-sessions 2>&1 || true; " +
                "printf '\\n=== PROCESSI ===\\n'; ps -A -o pid,comm 2>&1 | head -n 65",
            20000
        )
    }

    fun listFiles(path: String): List<FileEntry> = withClient { ssh ->
        ssh.newSFTPClient().use { sftp ->
            sftp.ls(path).filter { it.name != "." && it.name != ".." }
                .map { FileEntry(it.name, it.isDirectory, it.attributes.size) }
                .sortedWith(compareByDescending<FileEntry> { it.directory }.thenBy { it.name.lowercase() })
                .take(300)
        }
    }

    fun readPreview(path: String): String = withClient { ssh ->
        exec(ssh, "head -c 65536 -- ${shQuote(path)}", 65536)
    }

    companion object {
        fun exec(ssh: SSHClient, shellCommand: String, maxBytes: Int): String {
            ssh.startSession().use { session ->
                val command = session.exec(shellCommand)
                val output = ByteArrayOutputStream()
                val buffer = ByteArray(4096)
                while (output.size() < maxBytes) {
                    val count = command.inputStream.read(buffer, 0, minOf(buffer.size, maxBytes - output.size()))
                    if (count < 0) break
                    output.write(buffer, 0, count)
                }
                // Allow EOF before closing channel; avoid blocking on a large/unbounded command.
                command.close()
                return output.toString("UTF-8")
            }
        }
    }
}
