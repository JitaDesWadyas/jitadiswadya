@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
package dev.jita.workspace

import android.content.Context
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.foundation.Canvas
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// FEIM-OTT design tokens. Ink, parchment, brass and restrained coral.
private val Backdrop = Color(0xFF0F0E11)
private val Panel = Color(0xFF1A181D)
private val Panel2 = Color(0xFF25232A)
private val Ink = Color(0xFFF4EFE6)
private val Muted = Color(0xFFA79D8F)
private val Mint = Color(0xFFFBBF24) // Retains the existing semantic name for existing screens.
private val Brass = Color(0xFFFBBF24)
private val Coral = Color(0xFFED967A)
private val Line = Color(0xFF4A3A2C)
private val SoftText = Color(0xFFD3C9BB)
private val Green = Color(0xFF8CCBAE)

@Composable
fun WorkbenchTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Brass, onPrimary = Color(0xFF231600),
            secondary = Coral, onSecondary = Backdrop,
            background = Backdrop, onBackground = Ink,
            surface = Panel, onSurface = Ink,
            surfaceVariant = Panel2, onSurfaceVariant = SoftText,
            outline = Line
        ),
        typography = Typography(
            headlineLarge = TextStyle(fontSize = 32.sp, lineHeight = 34.sp, fontWeight = FontWeight.Black, letterSpacing = (-1.1).sp),
            headlineMedium = TextStyle(fontSize = 26.sp, lineHeight = 29.sp, fontWeight = FontWeight.Bold, letterSpacing = (-0.8).sp),
            titleLarge = TextStyle(fontSize = 20.sp, fontWeight = FontWeight.Bold, letterSpacing = (-0.4).sp),
            bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 20.sp),
            labelMedium = TextStyle(fontSize = 12.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.5.sp)
        ),
        content = content
    )
}

@Composable
private fun LabelStrip(label: String, modifier: Modifier = Modifier, color: Color = Brass) {
    Row(modifier, verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(9.dp)) {
        Box(Modifier.width(20.dp).height(2.dp).background(color))
        Text(label.uppercase(), fontSize = 10.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold, color = color)
    }
}

@Composable
private fun WorkspaceTop(title: String, subtitle: String, action: (@Composable RowScope.() -> Unit)? = null) {
    Column(Modifier.fillMaxWidth().padding(start = 20.dp, end = 14.dp, top = 19.dp, bottom = 16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
        LabelStrip("JITA / WORKBENCH")
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(title, style = MaterialTheme.typography.headlineMedium, modifier = Modifier.weight(1f))
            if (action != null) Row(content = action)
        }
        Text(subtitle, color = SoftText, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun NavButton(label: String, icon: ImageVector, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Column(
        modifier.height(62.dp).clip(RoundedCornerShape(11.dp))
            .background(if (selected) Brass.copy(alpha = .09f) else Color.Transparent)
            .clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(icon, contentDescription = label, tint = if (selected) Brass else Muted, modifier = Modifier.size(20.dp))
        Spacer(Modifier.height(5.dp))
        Text(label.uppercase(), color = if (selected) Ink else Muted, fontSize = 9.sp,
            letterSpacing = 1.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun MainScreen(store: SettingsStore, tab: Int, changeTab: (Int) -> Unit, launch: (Workspace) -> Unit) {
    Scaffold(
        containerColor = Backdrop,
        bottomBar = {
            Column(Modifier.background(Backdrop)) {
                HorizontalDivider(color = Line.copy(alpha = .75f))
                Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 5.dp)) {
                    NavButton("Home", Icons.Rounded.SpaceDashboard, tab == 0, Modifier.weight(1f)) { changeTab(0) }
                    NavButton("File", Icons.Rounded.FolderOpen, tab == 1, Modifier.weight(1f)) { changeTab(1) }
                    NavButton("Sessioni", Icons.Rounded.Terminal, tab == 2, Modifier.weight(1f)) { changeTab(2) }
                    NavButton("Setup", Icons.Rounded.Tune, tab == 3, Modifier.weight(1f)) { changeTab(3) }
                }
            }
        }
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            when (tab) {
                0 -> HomeScreen(store, launch, { changeTab(3) })
                1 -> FileBrowser(store)
                2 -> ProcessesScreen(store)
                3 -> ConfigurationScreen(store)
            }
        }
    }
}

@Composable
private fun HomeScreen(store: SettingsStore, launch: (Workspace) -> Unit, settings: () -> Unit) {
    val configured = store.load().configured
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 14.dp)) {
        Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 14.dp, top = 17.dp, bottom = 13.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                LabelStrip("JITA / WORKSPACE")
                Spacer(Modifier.height(6.dp))
                Text("Control centre", style = MaterialTheme.typography.headlineLarge)
            }
            IconButton(onClick = settings, modifier = Modifier.background(Panel2, RoundedCornerShape(12.dp))) {
                Icon(Icons.Rounded.Settings, contentDescription = "Configurazione", tint = SoftText)
            }
        }
        // A tactical, subtle grid rather than a heavy illustration; drawn natively by Compose.
        Box(
            Modifier.fillMaxWidth().padding(horizontal = 18.dp).height(175.dp)
                .clip(RoundedCornerShape(17.dp))
                .background(Brush.linearGradient(listOf(Color(0xFF33281F), Color(0xFF211D1D), Color(0xFF171519))))
                .border(1.dp, Color(0xFF655039), RoundedCornerShape(17.dp))
        ) {
            Canvas(Modifier.fillMaxSize()) {
                val grid = 27.dp.toPx()
                var x = 0f
                while (x < size.width) {
                    drawLine(Brass.copy(alpha = .05f), Offset(x, 0f), Offset(x, size.height), 1f)
                    x += grid
                }
                var y = 0f
                while (y < size.height) {
                    drawLine(Brass.copy(alpha = .055f), Offset(0f, y), Offset(size.width, y), 1f)
                    y += grid
                }
                drawCircle(Brass.copy(alpha=.13f), radius = size.minDimension * .43f,
                    center = Offset(size.width * .92f, size.height * .22f), style=Stroke(1.5f))
                drawCircle(Brass.copy(alpha=.09f), radius = size.minDimension * .32f,
                    center = Offset(size.width * .92f, size.height * .22f), style=Stroke(1.5f))
            }
            Column(Modifier.fillMaxSize().padding(19.dp), verticalArrangement = Arrangement.SpaceBetween) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(Modifier.size(7.dp).clip(RoundedCornerShape(100)).background(if (configured) Green else Coral))
                    Text(if (configured) "LOCAL LINK CONFIGURED" else "SETUP REQUIRED",
                        color = if (configured) Green else Coral, fontSize = 10.sp, fontWeight = FontWeight.Bold,
                        letterSpacing = 1.6.sp)
                }
                Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text("ONE SYSTEM.", fontSize = 25.sp, fontWeight = FontWeight.Black,
                        color = Ink, letterSpacing = (-0.5).sp)
                    Text("INFINITE SESSIONS.", fontSize = 19.sp, fontWeight = FontWeight.Bold,
                        color = Brass, letterSpacing = (-0.3).sp)
                    Spacer(Modifier.height(3.dp))
                    Text("REDMAGIC  /  TERMUX  /  UBUNTU", color = SoftText,
                        fontSize = 10.sp, letterSpacing = 1.sp, fontFamily = FontFamily.Monospace)
                }
            }
        }
        Spacer(Modifier.height(21.dp))
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp), verticalAlignment = Alignment.CenterVertically) {
            LabelStrip("I TUOI SPAZI", Modifier.weight(1f))
            Text("05  /  ACCESSI", color = Muted, fontSize = 10.sp,
                fontFamily = FontFamily.Monospace, letterSpacing = 1.sp)
        }
        Spacer(Modifier.height(12.dp))
        Workspace.entries.toList().chunked(2).forEach { row ->
            Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 5.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEach { space -> WorkspaceTile(space, Modifier.weight(1f)) { launch(space) } }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
        Spacer(Modifier.height(18.dp))
        Row(Modifier.fillMaxWidth().padding(horizontal = 19.dp)
            .clip(RoundedCornerShape(13.dp)).background(Panel)
            .border(1.dp, Line.copy(alpha=.55f), RoundedCornerShape(13.dp))
            .clickable(onClick = settings).padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Icon(Icons.Rounded.Shield, contentDescription = null, tint = Brass, modifier = Modifier.size(21.dp))
            Column(Modifier.weight(1f)) {
                Text(if (configured) "Identità SSH verificata" else "Collega il tuo Termux",
                    fontSize = 13.sp, color = Ink, fontWeight = FontWeight.Bold)
                Text("Solo 127.0.0.1 · i processi restano in tmux",
                    fontSize = 11.sp, color = Muted)
            }
            Icon(Icons.Rounded.ChevronRight, contentDescription = null, tint = Brass)
        }
    }
}

@Composable
private fun WorkspaceTile(space: Workspace, modifier: Modifier, open: () -> Unit) {
    val symbol = when(space) {
        Workspace.CODEX -> Icons.Rounded.Code
        Workspace.CLAUDE -> Icons.Rounded.AutoAwesome
        Workspace.MNF -> Icons.Rounded.AutoGraph
        Workspace.FEIM -> Icons.Rounded.SportsEsports
        Workspace.UBUNTU -> Icons.Rounded.Terminal
    }
    Surface(
        modifier = modifier.height(149.dp).clickable(onClick = open),
        shape = RoundedCornerShape(15.dp), color = Panel,
        border = BorderStroke(1.dp, Line.copy(alpha = .85f))
    ) {
        Column(Modifier.fillMaxSize().padding(15.dp), verticalArrangement = Arrangement.SpaceBetween) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
                Box(Modifier.size(41.dp).clip(RoundedCornerShape(12.dp))
                    .background(space.accent.copy(alpha = .13f)), contentAlignment = Alignment.Center) {
                    Icon(symbol, contentDescription = null, tint = space.accent,
                        modifier = Modifier.size(22.dp))
                }
                Spacer(Modifier.weight(1f))
                Icon(Icons.Rounded.NorthEast, contentDescription = null, tint = Muted,
                    modifier = Modifier.size(15.dp))
            }
            Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(space.title, color = Ink, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                Text(space.subtitle, color = Muted, fontSize = 11.sp,
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

@Composable
private fun FileBrowser(store: SettingsStore) {
    val root = "/data/data/com.termux/files/home"
    var path by remember { mutableStateOf(root + "/dev") }
    var files by remember { mutableStateOf<List<FileEntry>>(emptyList()) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var selected by remember { mutableStateOf<String?>(null) }
    var preview by remember { mutableStateOf("") }
    var reload by remember { mutableIntStateOf(0) }
    val scope = rememberCoroutineScope()
    LaunchedEffect(path, reload) {
        busy = true; error = null
        val outcome = withContext(Dispatchers.IO) { runCatching { SshGateway(store.load()).listFiles(path) } }
        outcome.onSuccess { files = it }.onFailure { error = it.message ?: "Connessione SSH non disponibile" }
        busy = false
    }
    Column(Modifier.fillMaxSize()) {
        WorkspaceTop("File", "I file reali del tuo Termux")
        Surface(color = Panel, shape = RoundedCornerShape(15.dp), modifier = Modifier.fillMaxWidth().padding(horizontal = 17.dp)) {
            Row(Modifier.padding(horizontal = 10.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { if (path != "/") path = path.substringBeforeLast('/', "").ifBlank { "/" } }) { Icon(Icons.Rounded.ArrowUpward, "Sali") }
                Text(path.removePrefix(root).ifEmpty { "~" }, modifier = Modifier.weight(1f), fontSize = 12.sp, color = Muted, maxLines = 2)
                IconButton(onClick = { reload++ }) { Icon(Icons.Rounded.Refresh, "Ricarica") }
            }
        }
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 7.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Home" to root, "Progetti" to "$root/dev", "Ubuntu" to "$root/Ubuntu-Files/root").forEach { (name, target) ->
                SuggestionChip(onClick = { path = target }, label = { Text(name) })
            }
        }
        if (busy) LinearProgressIndicator(Modifier.fillMaxWidth().padding(horizontal = 19.dp))
        if (error != null) Text(error.orEmpty(), Modifier.padding(20.dp), color = Color(0xFFFF9BA6))
        if (selected != null) AlertDialog(
            onDismissRequest = { selected = null },
            confirmButton = { TextButton(onClick = { selected = null }) { Text("Chiudi") } },
            title = { Text(selected!!.substringAfterLast('/')) },
            text = { Text(preview, modifier = Modifier.heightIn(max = 360.dp).verticalScroll(rememberScrollState()), fontSize = 12.sp, lineHeight = 17.sp) }
        )
        LazyColumn(contentPadding = PaddingValues(17.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(files, key = { it.name }) { item ->
                Surface(color = Panel, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth().clickable {
                    val target = path.trimEnd('/') + "/" + item.name
                    if (item.directory) { path = target; files = emptyList() }
                    else {
                        val permitted = setOf("txt", "md", "log", "json", "toml", "yaml", "yml", "xml", "html", "css", "js", "ts", "tsx", "jsx", "py", "go", "rs", "kt", "java", "cbl", "c", "h", "sh", "ini", "conf", "env", "sql")
                        selected = target
                        if (item.name.substringAfterLast('.', "").lowercase() !in permitted) {
                            preview = "Anteprima disponibile solo per file di testo. Usa Material Files per file binari, immagini e archivi."
                        } else {
                            preview = "Caricamento anteprima..."
                            scope.launch {
                                preview = withContext(Dispatchers.IO) {
                                    runCatching { SshGateway(store.load()).readPreview(target) }.getOrElse { "Errore: ${it.message}" }
                                }
                            }
                        }
                    }
                }) {
                    Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Icon(if (item.directory) Icons.Rounded.Folder else Icons.Rounded.Description, null, tint = if (item.directory) Color(0xFFF6C77C) else Color(0xFF9DC1DA))
                        Text(item.name, Modifier.weight(1f), maxLines = 2, fontSize = 13.sp)
                        if (!item.directory) Text("${item.size / 1024} KB", color = Muted, fontSize = 11.sp)
                        Icon(Icons.Rounded.ChevronRight, null, tint = Muted)
                    }
                }
            }
        }
    }
}

@Composable
private fun ProcessesScreen(store: SettingsStore) {
    var snapshot by remember { mutableStateOf("Caricamento…") }
    var refresh by remember { mutableIntStateOf(0) }
    LaunchedEffect(refresh) {
        snapshot = withContext(Dispatchers.IO) {
            runCatching { SshGateway(store.load()).sessionsAndProcesses() }.getOrElse { "Errore SSH: ${it.message}" }
        }
    }
    Column(Modifier.fillMaxSize()) {
        WorkspaceTop("Processi", "Sessioni tmux nello stesso ambiente", action = {
            IconButton(onClick = { refresh++ }) { Icon(Icons.Rounded.Refresh, "Aggiorna") }
        })
        Surface(color = Panel, shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxSize().padding(17.dp)) {
            Text(snapshot, fontSize = 12.sp, lineHeight = 20.sp, modifier = Modifier.verticalScroll(rememberScrollState()).padding(18.dp))
        }
    }
}

@Composable
private fun ConfigurationScreen(store: SettingsStore) {
    val initial = remember { store.load() }
    var user by remember { mutableStateOf(initial.username) }
    var password by remember { mutableStateOf("") }
    var fingerprint by remember { mutableStateOf(initial.fingerprint) }
    var port by remember { mutableStateOf(initial.port.toString()) }
    var message by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        WorkspaceTop("Connessione", "Solo SSH locale • nessun cloud")
        Column(Modifier.padding(horizontal = 19.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            SettingsLabel("Indirizzo", "127.0.0.1 — fisso, non raggiunge altri dispositivi")
            OutlinedTextField(value = user, onValueChange = { user = it }, label = { Text("Utente Termux (whoami)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            OutlinedTextField(value = password, onValueChange = { password = it }, label = { Text(if (initial.password.isBlank()) "Password SSH" else "Nuova password (vuoto = mantieni)") },
                visualTransformation = PasswordVisualTransformation(), singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = port, onValueChange = { port = it.filter(Char::isDigit).take(5) }, label = { Text("Porta SSH") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = fingerprint, onValueChange = { fingerprint = it }, label = { Text("Impronta chiave server SHA256:…") }, minLines = 2, modifier = Modifier.fillMaxWidth())
            Surface(color = Panel2, shape = RoundedCornerShape(15.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text("Da Termux nativo", fontWeight = FontWeight.SemiBold)
                    Text("whoami", color = Mint, fontSize = 13.sp)
                    Text("passwd", color = Mint, fontSize = 13.sp)
                    Text("ssh-keygen -lf $" + "PREFIX/etc/ssh/ssh_host_ed25519_key.pub -E sha256", color = Mint, fontSize = 12.sp)
                    Text("Copia soltanto SHA256:... (l'impronta del server, non una password). Avvia sshd -p 8022 -o ListenAddress=127.0.0.1", color = Muted, fontSize = 12.sp)
                }
            }
            Button(onClick = {
                val parsed = port.toIntOrNull()
                if (user.isBlank() || parsed == null || parsed !in 1024..65535 || fingerprint.isBlank()) {
                    message = "Inserisci utente, porta e impronta validi"
                } else {
                    store.save(user, fingerprint, parsed, password)
                    password = ""
                    message = "Configurazione salvata."
                }
            }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Rounded.Save, null); Spacer(Modifier.width(7.dp)); Text("Salva impostazioni") }
            OutlinedButton(onClick = {
                scope.launch {
                    message = "Connessione in corso…"
                    message = withContext(Dispatchers.IO) {
                        runCatching { SshGateway(store.load()).test() }.getOrElse { "Connessione fallita: ${it.message}" }
                    }
                }
            }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Rounded.WifiTethering, null); Spacer(Modifier.width(7.dp)); Text("Verifica collegamento") }
            if (message.isNotBlank()) Text(message, color = Mint, fontSize = 13.sp)
            Spacer(Modifier.height(18.dp))
            SettingsLabel("Persistenza", "Le sessioni restano in tmux quando torni alla Home. Android può comunque interrompere Termux per risparmiare batteria. Imposta Termux su Batteria senza restrizioni.")
            Spacer(Modifier.height(12.dp))
        }
    }
}

@Composable
private fun SettingsLabel(title: String, subtitle: String) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(title, fontWeight = FontWeight.SemiBold)
        Text(subtitle, color = Muted, fontSize = 12.sp, lineHeight = 17.sp)
    }
}

@Composable
fun TerminalScreen(space: Workspace, controller: TerminalController, store: SettingsStore,
                   onDashboard: () -> Unit, onSettings: () -> Unit) {
    var showLauncher by remember { mutableStateOf(false) }
    var command by remember { mutableStateOf(store.startupCommand(space)) }
    Scaffold(containerColor = Backdrop) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            Row(Modifier.fillMaxWidth().background(Panel).padding(start = 5.dp, end = 8.dp, top = 7.dp, bottom = 6.dp),
                verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onDashboard, modifier = Modifier.size(44.dp)) {
                    Icon(Icons.Rounded.ArrowBack, "Torna al workspace", tint = SoftText)
                }
                Box(Modifier.size(40.dp).clip(RoundedCornerShape(12.dp))
                    .background(space.accent.copy(alpha = .15f)), contentAlignment = Alignment.Center) {
                    Text(space.tag, color = space.accent, fontWeight = FontWeight.Black,
                        fontSize = 12.sp, letterSpacing = .5.sp)
                }
                Spacer(Modifier.width(11.dp))
                Column(Modifier.weight(1f)) {
                    Text(space.title, fontSize = 17.sp, fontWeight = FontWeight.Bold, color = Ink)
                    Text(controller.status, fontSize = 10.sp, color = Muted,
                        maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                IconButton(onClick = { showLauncher = true }, modifier = Modifier.size(42.dp)) {
                    Icon(Icons.Rounded.PlayArrow, "Configura comando", tint = Brass)
                }
                IconButton(onClick = { controller.focusKeyboard() }, modifier = Modifier.size(42.dp)) {
                    Icon(Icons.Rounded.Keyboard, "Apri tastiera Android", tint = Brass)
                }
                IconButton(onClick = { controller.reconnect() }, modifier = Modifier.size(42.dp)) {
                    Icon(Icons.Rounded.Refresh, "Riconnetti", tint = SoftText)
                }
                IconButton(onClick = onSettings, modifier = Modifier.size(42.dp)) {
                    Icon(Icons.Rounded.Tune, "Impostazioni", tint = SoftText)
                }
            }
            HorizontalDivider(color = Line)
            Row(Modifier.fillMaxWidth().background(Backdrop).padding(horizontal = 15.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(6.dp).clip(RoundedCornerShape(100)).background(Green))
                Spacer(Modifier.width(8.dp))
                Text("COMANDO / ${store.startupCommand(space).uppercase()}", color = SoftText,
                    fontFamily = FontFamily.Monospace, fontSize = 10.sp, letterSpacing = 1.sp,
                    modifier = Modifier.weight(1f))
                Text("LOCAL · 8022", color = Muted, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
            }
            AndroidView(factory = { controller.makeWebView(it) }, modifier = Modifier.weight(1f).fillMaxWidth())
            HorizontalDivider(color = Line)
            Row(Modifier.fillMaxWidth().background(Panel).padding(start = 8.dp, end = 7.dp, top = 6.dp, bottom = 6.dp),
                verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { controller.focusKeyboard() }, modifier = Modifier.size(45.dp)) {
                    Icon(Icons.Rounded.Keyboard, "Mostra tastiera", tint = Brass)
                }
                Row(Modifier.weight(1f).horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                TinyKey("CTRL${if (controller.ctrlArmed) " ●" else ""}", { controller.toggleCtrl() }, controller.ctrlArmed)
                TinyKey("ESC", { controller.sendInput("\u001b") })
                TinyKey("TAB", { controller.sendInput("\t") })
                TinyKey("←", { controller.sendInput("\u001b[D") })
                TinyKey("↓", { controller.sendInput("\u001b[B") })
                TinyKey("↑", { controller.sendInput("\u001b[A") })
                TinyKey("→", { controller.sendInput("\u001b[C") })
                TinyKey("ENTER", { controller.sendInput("\r") })
                TinyKey("-A", { controller.changeFont(-1) })
                TinyKey("A+", { controller.changeFont(1) })
                }
            }
        }
    }
    if (showLauncher) AlertDialog(
        onDismissRequest = { showLauncher = false },
        containerColor = Panel,
        title = { Text("Comando per ${space.title}") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Questo è il tuo launcher originale Termux. Viene avviato automaticamente alla prossima apertura, senza sessioni tmux aggiuntive.",
                    fontSize = 13.sp, color = SoftText)
                OutlinedTextField(value = command, onValueChange = { command = it },
                    label = { Text("Comando personalizzato") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            }
        },
        dismissButton = { TextButton(onClick = { showLauncher = false }) { Text("Annulla") } },
        confirmButton = { TextButton(onClick = {
            store.setStartupCommand(space, command)
            showLauncher = false
        }) { Text("Salva") } }
    )
}

@Composable
private fun TinyKey(label: String, callback: () -> Unit, selected: Boolean = false) {
    Surface(
        color = if (selected) Color(0xFF564026) else Panel2,
        shape = RoundedCornerShape(9.dp),
        border = BorderStroke(1.dp, if (selected) Brass else Line.copy(alpha = .5f)),
        modifier = Modifier.height(40.dp).clickable(onClick = callback)
    ) { Box(Modifier.padding(horizontal = 14.dp), contentAlignment = Alignment.Center) {
        Text(label, fontSize = 12.sp, color = if (selected) Brass else Ink,
            fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
    } }
}
