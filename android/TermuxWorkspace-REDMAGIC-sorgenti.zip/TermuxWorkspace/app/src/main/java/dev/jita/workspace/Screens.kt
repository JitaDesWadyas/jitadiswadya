@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
package dev.jita.workspace

import android.content.Context
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val Backdrop = Color(0xFF0B111A)
private val Panel = Color(0xFF141D29)
private val Panel2 = Color(0xFF1B2836)
private val Ink = Color(0xFFEAF4FA)
private val Muted = Color(0xFF92A6B7)
private val Mint = Color(0xFF70E0BD)

@Composable
fun WorkbenchTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Mint, onPrimary = Color(0xFF042B20),
            secondary = Color(0xFF9FC3EE), background = Backdrop,
            surface = Panel, onBackground = Ink, onSurface = Ink,
            surfaceVariant = Panel2, onSurfaceVariant = Muted
        ),
        typography = Typography(),
        content = content
    )
}

@Composable
private fun WorkspaceTop(title: String, subtitle: String, action: (@Composable RowScope.() -> Unit)? = null) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            if (action != null) Row(content = action)
        }
        Text(subtitle, color = Muted, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun MainScreen(store: SettingsStore, tab: Int, changeTab: (Int) -> Unit, launch: (Workspace) -> Unit) {
    val nav = listOf(
        Triple("Home", Icons.Rounded.Dashboard, 0),
        Triple("File", Icons.Rounded.FolderOpen, 1),
        Triple("Processi", Icons.Rounded.MonitorHeart, 2),
        Triple("Config", Icons.Rounded.Tune, 3)
    )
    Scaffold(
        containerColor = Backdrop,
        bottomBar = {
            NavigationBar(containerColor = Panel, tonalElevation = 0.dp) {
                nav.forEach { (label, icon, index) ->
                    NavigationBarItem(
                        selected = tab == index, onClick = { changeTab(index) },
                        icon = { Icon(icon, label) }, label = { Text(label, fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(selectedIconColor = Mint, selectedTextColor = Mint,
                            indicatorColor = Color(0xFF273C40), unselectedIconColor = Muted, unselectedTextColor = Muted)
                    )
                }
            }
        }
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            when (tab) {
                0 -> HomeScreen(store, launch, { changeTab(3) })
                1 -> FileBrowser(store)
                2 -> ProcessesScreen(store)
                3 -> ConfigurationScreen(store)
            }
        }
    }
}

@Composable
private fun HomeScreen(store: SettingsStore, launch: (Workspace) -> Unit, settings: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        WorkspaceTop("Workspace", "Un solo Termux. Tutti i tuoi progetti.", action = {
            IconButton(onClick = settings) { Icon(Icons.Rounded.Settings, "Impostazioni") }
        })
        val configured = store.load().configured
        Surface(color = Panel, shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp)) {
            Column(Modifier.padding(19.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Icon(Icons.Rounded.Lan, null, tint = if (configured) Mint else Color(0xFFFFC475))
                    Text(if (configured) "SSH locale configurato" else "Configurazione necessaria", fontWeight = FontWeight.SemiBold)
                }
                Text("REDMAGIC • 127.0.0.1:8022", color = Muted, fontSize = 12.sp)
                Text("Le sessioni girano nel Termux originale e restano su tmux quando esci dalle finestre.", color = Muted, fontSize = 13.sp, lineHeight = 19.sp)
                if (!configured) FilledTonalButton(onClick = settings) { Text("Configura connessione") }
            }
        }
        Spacer(Modifier.height(23.dp))
        Text("I tuoi spazi", modifier = Modifier.padding(horizontal = 22.dp), fontWeight = FontWeight.Bold, fontSize = 19.sp)
        Text("Ogni icona apre un task Android distinto", modifier = Modifier.padding(start = 22.dp, top = 5.dp), color = Muted, fontSize = 12.sp)
        Spacer(Modifier.height(12.dp))
        Workspace.entries.toList().chunked(2).forEach { row ->
            Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 5.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEach { space ->
                    WorkspaceTile(space, Modifier.weight(1f), { launch(space) })
                }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
        Spacer(Modifier.height(20.dp))
        Surface(color = Panel2, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp)) {
            Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Icon(Icons.Rounded.Security, null, tint = Mint)
                Text("Collegamento verificato con impronta SSH. Nessuna connessione a server esterni.", fontSize = 12.sp, color = Muted)
            }
        }
        Spacer(Modifier.height(22.dp))
    }
}

@Composable
private fun WorkspaceTile(space: Workspace, modifier: Modifier, open: () -> Unit) {
    Surface(
        modifier = modifier.height(148.dp).clickable(onClick = open),
        shape = RoundedCornerShape(23.dp), color = Panel,
        border = BorderStroke(1.dp, space.accent.copy(alpha = 0.14f))
    ) {
        Column(Modifier.padding(17.dp), verticalArrangement = Arrangement.SpaceBetween) {
            Box(Modifier.size(42.dp).clip(RoundedCornerShape(14.dp)).background(space.accent.copy(alpha = 0.16f)), contentAlignment = Alignment.Center) {
                Text(space.tag, fontSize = 14.sp, fontWeight = FontWeight.Black, color = space.accent)
            }
            Column {
                Text(space.title, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                Text(space.subtitle, color = Muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

@Composable
private fun FileBrowser(store: SettingsStore) {
    val root = "/data/data/com.termux/files/home"
    var path by remember { mutableStateOf(root + "/dev") }
    var files by remember { mutableStateOf<List<FileEntry>>(emptyList()) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var selected by remember { mutableStateOf<String?>(null) }
    var preview by remember { mutableStateOf("") }
    var reload by remember { mutableIntStateOf(0) }
    val scope = rememberCoroutineScope()
    LaunchedEffect(path, reload) {
        busy = true; error = null
        val outcome = withContext(Dispatchers.IO) { runCatching { SshGateway(store.load()).listFiles(path) } }
        outcome.onSuccess { files = it }.onFailure { error = it.message ?: "Connessione SSH non disponibile" }
        busy = false
    }
    Column(Modifier.fillMaxSize()) {
        WorkspaceTop("File", "I file reali del tuo Termux")
        Surface(color = Panel, shape = RoundedCornerShape(15.dp), modifier = Modifier.fillMaxWidth().padding(horizontal = 17.dp)) {
            Row(Modifier.padding(horizontal = 10.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { if (path != "/") path = path.substringBeforeLast('/', "").ifBlank { "/" } }) { Icon(Icons.Rounded.ArrowUpward, "Sali") }
                Text(path.removePrefix(root).ifEmpty { "~" }, modifier = Modifier.weight(1f), fontSize = 12.sp, color = Muted, maxLines = 2)
                IconButton(onClick = { reload++ }) { Icon(Icons.Rounded.Refresh, "Ricarica") }
            }
        }
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 7.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Home" to root, "Progetti" to "$root/dev", "Ubuntu" to "$root/Ubuntu-Files/root").forEach { (name, target) ->
                SuggestionChip(onClick = { path = target }, label = { Text(name) })
            }
        }
        if (busy) LinearProgressIndicator(Modifier.fillMaxWidth().padding(horizontal = 19.dp))
        if (error != null) Text(error.orEmpty(), Modifier.padding(20.dp), color = Color(0xFFFF9BA6))
        if (selected != null) AlertDialog(
            onDismissRequest = { selected = null },
            confirmButton = { TextButton(onClick = { selected = null }) { Text("Chiudi") } },
            title = { Text(selected!!.substringAfterLast('/')) },
            text = { Text(preview, modifier = Modifier.heightIn(max = 360.dp).verticalScroll(rememberScrollState()), fontSize = 12.sp, lineHeight = 17.sp) }
        )
        LazyColumn(contentPadding = PaddingValues(17.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(files, key = { it.name }) { item ->
                Surface(color = Panel, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth().clickable {
                    val target = path.trimEnd('/') + "/" + item.name
                    if (item.directory) { path = target; files = emptyList() }
                    else {
                        val permitted = setOf("txt", "md", "log", "json", "toml", "yaml", "yml", "xml", "html", "css", "js", "ts", "tsx", "jsx", "py", "go", "rs", "kt", "java", "cbl", "c", "h", "sh", "ini", "conf", "env", "sql")
                        selected = target
                        if (item.name.substringAfterLast('.', "").lowercase() !in permitted) {
                            preview = "Anteprima disponibile solo per file di testo. Usa Material Files per file binari, immagini e archivi."
                        } else {
                            preview = "Caricamento anteprima..."
                            scope.launch {
                                preview = withContext(Dispatchers.IO) {
                                    runCatching { SshGateway(store.load()).readPreview(target) }.getOrElse { "Errore: ${it.message}" }
                                }
                            }
                        }
                    }
                }) {
                    Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Icon(if (item.directory) Icons.Rounded.Folder else Icons.Rounded.Description, null, tint = if (item.directory) Color(0xFFF6C77C) else Color(0xFF9DC1DA))
                        Text(item.name, Modifier.weight(1f), maxLines = 2, fontSize = 13.sp)
                        if (!item.directory) Text("${item.size / 1024} KB", color = Muted, fontSize = 11.sp)
                        Icon(Icons.Rounded.ChevronRight, null, tint = Muted)
                    }
                }
            }
        }
    }
}

@Composable
private fun ProcessesScreen(store: SettingsStore) {
    var snapshot by remember { mutableStateOf("Caricamento…") }
    var refresh by remember { mutableIntStateOf(0) }
    LaunchedEffect(refresh) {
        snapshot = withContext(Dispatchers.IO) {
            runCatching { SshGateway(store.load()).sessionsAndProcesses() }.getOrElse { "Errore SSH: ${it.message}" }
        }
    }
    Column(Modifier.fillMaxSize()) {
        WorkspaceTop("Processi", "Sessioni tmux nello stesso ambiente", action = {
            IconButton(onClick = { refresh++ }) { Icon(Icons.Rounded.Refresh, "Aggiorna") }
        })
        Surface(color = Panel, shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxSize().padding(17.dp)) {
            Text(snapshot, fontSize = 12.sp, lineHeight = 20.sp, modifier = Modifier.verticalScroll(rememberScrollState()).padding(18.dp))
        }
    }
}

@Composable
private fun ConfigurationScreen(store: SettingsStore) {
    val initial = remember { store.load() }
    var user by remember { mutableStateOf(initial.username) }
    var password by remember { mutableStateOf("") }
    var fingerprint by remember { mutableStateOf(initial.fingerprint) }
    var port by remember { mutableStateOf(initial.port.toString()) }
    var message by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        WorkspaceTop("Connessione", "Solo SSH locale • nessun cloud")
        Column(Modifier.padding(horizontal = 19.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            SettingsLabel("Indirizzo", "127.0.0.1 — fisso, non raggiunge altri dispositivi")
            OutlinedTextField(value = user, onValueChange = { user = it }, label = { Text("Utente Termux (whoami)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            OutlinedTextField(value = password, onValueChange = { password = it }, label = { Text(if (initial.password.isBlank()) "Password SSH" else "Nuova password (vuoto = mantieni)") },
                visualTransformation = PasswordVisualTransformation(), singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = port, onValueChange = { port = it.filter(Char::isDigit).take(5) }, label = { Text("Porta SSH") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = fingerprint, onValueChange = { fingerprint = it }, label = { Text("Impronta chiave server SHA256:…") }, minLines = 2, modifier = Modifier.fillMaxWidth())
            Surface(color = Panel2, shape = RoundedCornerShape(15.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text("Da Termux nativo", fontWeight = FontWeight.SemiBold)
                    Text("whoami", color = Mint, fontSize = 13.sp)
                    Text("passwd", color = Mint, fontSize = 13.sp)
                    Text("ssh-keygen -lf $" + "PREFIX/etc/ssh/ssh_host_ed25519_key.pub -E sha256", color = Mint, fontSize = 12.sp)
                    Text("Copia soltanto SHA256:... (l'impronta del server, non una password). Avvia sshd -p 8022 -o ListenAddress=127.0.0.1", color = Muted, fontSize = 12.sp)
                }
            }
            Button(onClick = {
                val parsed = port.toIntOrNull()
                if (user.isBlank() || parsed == null || parsed !in 1024..65535 || fingerprint.isBlank()) {
                    message = "Inserisci utente, porta e impronta validi"
                } else {
                    store.save(user, fingerprint, parsed, password)
                    password = ""
                    message = "Configurazione salvata."
                }
            }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Rounded.Save, null); Spacer(Modifier.width(7.dp)); Text("Salva impostazioni") }
            OutlinedButton(onClick = {
                scope.launch {
                    message = "Connessione in corso…"
                    message = withContext(Dispatchers.IO) {
                        runCatching { SshGateway(store.load()).test() }.getOrElse { "Connessione fallita: ${it.message}" }
                    }
                }
            }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Rounded.WifiTethering, null); Spacer(Modifier.width(7.dp)); Text("Verifica collegamento") }
            if (message.isNotBlank()) Text(message, color = Mint, fontSize = 13.sp)
            Spacer(Modifier.height(18.dp))
            SettingsLabel("Persistenza", "Le sessioni restano in tmux quando torni alla Home. Android può comunque interrompere Termux per risparmiare batteria. Imposta Termux su Batteria senza restrizioni.")
            Spacer(Modifier.height(12.dp))
        }
    }
}

@Composable
private fun SettingsLabel(title: String, subtitle: String) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(title, fontWeight = FontWeight.SemiBold)
        Text(subtitle, color = Muted, fontSize = 12.sp, lineHeight = 17.sp)
    }
}

@Composable
fun TerminalScreen(space: Workspace, controller: TerminalController, store: SettingsStore,
                   onDashboard: () -> Unit, onSettings: () -> Unit) {
    var showLauncher by remember { mutableStateOf(false) }
    var command by remember { mutableStateOf(store.startupCommand(space)) }
    Scaffold(containerColor = Backdrop) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            Row(Modifier.fillMaxWidth().padding(start = 8.dp, end = 12.dp, top = 6.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onDashboard) { Icon(Icons.Rounded.ArrowBack, "Workspace") }
                Box(Modifier.size(38.dp).clip(RoundedCornerShape(12.dp)).background(space.accent.copy(alpha = 0.2f)), contentAlignment = Alignment.Center) {
                    Text(space.tag, color = space.accent, fontWeight = FontWeight.Black, fontSize = 13.sp)
                }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(space.title, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    Text(controller.status, fontSize = 10.sp, color = Muted, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                IconButton(onClick = { showLauncher = true }) { Icon(Icons.Rounded.PlayArrow, "Avvia comando") }
                IconButton(onClick = { controller.reconnect() }) { Icon(Icons.Rounded.Refresh, "Riconnetti") }
                IconButton(onClick = onSettings) { Icon(Icons.Rounded.Tune, "Impostazioni") }
            }
            HorizontalDivider(color = Color(0xFF233342))
            AndroidView(factory = { controller.makeWebView(it) }, modifier = Modifier.weight(1f).fillMaxWidth())
            HorizontalDivider(color = Color(0xFF233342))
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).background(Panel).padding(horizontal = 8.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                TinyKey("CTRL${if (controller.ctrlArmed) " ●" else ""}", { controller.toggleCtrl() }, controller.ctrlArmed)
                TinyKey("ESC", { controller.sendInput("\u001b") })
                TinyKey("TAB", { controller.sendInput("\t") })
                TinyKey("←", { controller.sendInput("\u001b[D") })
                TinyKey("↓", { controller.sendInput("\u001b[B") })
                TinyKey("↑", { controller.sendInput("\u001b[A") })
                TinyKey("→", { controller.sendInput("\u001b[C") })
                TinyKey("ENTER", { controller.sendInput("\r") })
                TinyKey("⌨", { controller.focusKeyboard() })
            }
        }
    }
    if (showLauncher) AlertDialog(
        onDismissRequest = { showLauncher = false },
        title = { Text("Avvia in ${space.title}") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Il comando viene inviato alla sessione ${space.sessionName} già aperta. Non crea un altro Ubuntu.", fontSize = 13.sp, color = Muted)
                OutlinedTextField(value = command, onValueChange = { command = it }, label = { Text("Il tuo comando") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            }
        },
        dismissButton = { TextButton(onClick = { showLauncher = false }) { Text("Annulla") } },
        confirmButton = { TextButton(onClick = {
            store.setStartupCommand(space, command)
            controller.runCommand(command)
            showLauncher = false
        }) { Text("Esegui") } }
    )
}

@Composable
private fun TinyKey(label: String, callback: () -> Unit, selected: Boolean = false) {
    Surface(
        color = if (selected) Color(0xFF255345) else Panel2,
        shape = RoundedCornerShape(10.dp), modifier = Modifier.height(37.dp).clickable(onClick = callback)
    ) { Box(Modifier.padding(horizontal = 13.dp), contentAlignment = Alignment.Center) {
        Text(label, fontSize = 12.sp, color = if (selected) Mint else Ink, fontWeight = FontWeight.SemiBold)
    } }
}
